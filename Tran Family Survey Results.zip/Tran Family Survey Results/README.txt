README.txt

# tran-family-survey
This is the hard-effort survey results you wanted right?

This took some time to make for you guys. I hope you downloaded it.
Any complaints will not be tolerated. A little description of this would
be that it is actually my first project ever! So I don't know if it
will turn out well. I am doing this mainly in hopes of being
able to understand computers better and you also get your long-awaited 
survey results which you could have gotten anyways if you had just 
went to the meeting we had planned out, but I guess everyone has
their extenuating circumstances

///////

I hope you enjoy this


## Installation

unzip the folder and extract the files

```
duh
```

## Usage

```python
import the files you want
.obviously
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
Please make sure to update tests as appropriate.

Doubt you guys are gonna contribute though

## License
[Kaitlyn and I made this](https://forms.gle/CznuyUa8sL9YrwfR9)